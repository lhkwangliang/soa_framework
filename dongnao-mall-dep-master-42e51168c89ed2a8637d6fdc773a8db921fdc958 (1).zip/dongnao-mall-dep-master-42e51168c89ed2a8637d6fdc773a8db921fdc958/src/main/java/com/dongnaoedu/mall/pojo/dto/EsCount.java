package com.dongnaoedu.mall.pojo.dto;

import java.io.Serializable;

/**
 * @author allen
 */
public class EsCount implements Serializable {

    private Integer count;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}

package com.dongnaoedu.mall.service;

public interface MemberFrontService {

    String imageUpload(Long userId, String token, String imgData);
}

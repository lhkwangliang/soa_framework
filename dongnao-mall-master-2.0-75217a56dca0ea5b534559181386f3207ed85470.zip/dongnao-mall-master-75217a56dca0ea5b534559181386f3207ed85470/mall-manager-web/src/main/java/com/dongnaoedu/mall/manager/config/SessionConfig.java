package com.dongnaoedu.mall.manager.config;

//@Configuration
//maxInactiveIntervalInSeconds: 设置Session失效时间，使用Redis Session之后，原Boot的server.session.timeout属性不再生效
//@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 1800)
public class SessionConfig {

}

package com.dongnaoedu.vip.shiro;

public class Constants {
    public static final String CURRENT_USER = "user";
}
